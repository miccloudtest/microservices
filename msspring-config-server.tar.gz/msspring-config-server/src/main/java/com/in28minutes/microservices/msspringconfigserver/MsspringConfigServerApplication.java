package com.in28minutes.microservices.msspringconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@EnableConfigServer
@SpringBootApplication

public class MsspringConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsspringConfigServerApplication.class, args);
	}
}
